export function toggleBold(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleBold().run();
}

export function toggleItalic(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleItalic().run();
}

export function toggleStrike(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleStrike().run();
}

export function toggleCode(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleCode().run();
}

export function setParagraph(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().setParagraph().run();
}

export function toggleHeading(editor, level) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleHeading({ level }).run();
}

export function setHeading(editor, level) {
    if (!editor) {
        return;
    }

    editor.chain().focus().setHeading({ level }).run();
}

export function toggleBlockquote(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleBlockquote().run();
}

export function insertHorizontalRule(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().setHorizontalRule().run();
}

export function toggleBulletList(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleBulletList().run();
}

export function toggleOrderedList(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().toggleOrderedList().run();
}

export function setTextAlign(editor, alignment) {
    if (!editor) {
        return;
    }

    const value = typeof alignment === "string" ? alignment.toLowerCase() : "";
    if (!value) {
        return;
    }

    editor.chain().focus().setTextAlign(value).run();
}

export function setLink(editor, href) {
    if (!editor) {
        return;
    }

    const url = typeof href === "string" ? href.trim() : "";
    if (!url) {
        return;
    }

    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
}

export function unsetLink(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().unsetLink().run();
}

export function setFontSize(editor, size) {
    if (!editor) {
        return;
    }

    const sizeValue = Number(size);
    if (!Number.isFinite(sizeValue)) {
        return;
    }

    editor.chain().focus().setMark("textStyle", { fontSize: `${sizeValue}px` }).run();
}

export function increaseIndent(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().increaseIndent().run();
}

export function decreaseIndent(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().decreaseIndent().run();
}

export function setFontFamily(editor, fontFamily) {
    if (!editor) {
        return;
    }

    const family = typeof fontFamily === "string" ? fontFamily.trim() : "";
    if (!family) {
        return;
    }

    editor.chain().focus().setMark("textStyle", { fontFamily: family }).run();
}

export function clearFontFamily(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().setMark("textStyle", { fontFamily: null }).run();
}

export function focusEditor(editor) {
    if (!editor) {
        return;
    }

    editor.commands.focus();
}

export function undo(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().undo().run();
}

export function redo(editor) {
    if (!editor) {
        return;
    }

    editor.chain().focus().redo().run();
}

export function replaceSelection(editor, content) {
    if (!editor) {
        return;
    }

    const text = typeof content === "string" ? content : "";
    editor.chain().focus().insertContent(text).run();
}

export function replaceTextRange(editor, from, to, content) {
    if (!editor) {
        return;
    }

    const start = Number(from);
    const end = Number(to);
    if (!Number.isFinite(start) || !Number.isFinite(end)) {
        return;
    }

    const text = typeof content === "string" ? content : "";
    const normalizedFrom = Math.max(0, Math.min(start, end));
    const normalizedTo = Math.max(normalizedFrom, Math.max(start, end));
    editor.chain().focus().setTextSelection({ from: normalizedFrom, to: normalizedTo }).insertContent(text).run();
}

export function appendParagraph(editor, content) {
    if (!editor) {
        return;
    }

    const text = typeof content === "string" ? content.trim() : "";
    if (!text) {
        return;
    }

    const paragraph = {
        type: "paragraph",
        content: [{ type: "text", text }]
    };

    editor.chain().focus().insertContentAt(editor.state.doc.content.size, paragraph).run();
}

export function scrollToPosition(editor, position) {
    if (!editor) {
        return;
    }

    const pos = Number(position);
    if (!Number.isFinite(pos)) {
        return;
    }

    editor.chain().focus().setTextSelection(pos).run();
    if (editor.view) {
        editor.view.scrollIntoView();
    }
}
